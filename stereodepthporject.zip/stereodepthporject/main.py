import cv2
import os
import matplotlib.pyplot as plt

image_folder = "images"

images = []
filenames = sorted(os.listdir(image_folder))

for file in filenames:
    img_path = os.path.join(image_folder, file)
    img = cv2.imread(img_path)
    
    if img is not None:
        images.append(img)
        print(f"Loaded: {file}")

print(f"\nTotal images loaded: {len(images)}")

# NEW DISPLAY METHOD
if len(images) > 0:
    img_rgb = cv2.cvtColor(images[0], cv2.COLOR_BGR2RGB)
    
    plt.imshow(img_rgb)
    plt.title("Sample Image")
    plt.axis("off")
    plt.show()

    # Function to calculate focus using Laplacian variance
def calculate_focus(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    variance = laplacian.var()
    return variance

# Calculate focus for each image
for i, img in enumerate(images):
    focus_value = calculate_focus(img)
    print(f"Image {i+1} Focus Measure: {focus_value}")


import numpy as np

# Convert all images to grayscale
gray_images = [cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) for img in images]

# Compute Laplacian for each image
laplacians = [cv2.Laplacian(gray, cv2.CV_64F) for gray in gray_images]

# Stack them into array
lap_stack = np.stack(laplacians, axis=-1)

# Take absolute values (important)
lap_stack = np.abs(lap_stack)

# Find index of max focus at each pixel
depth_map = np.argmax(lap_stack, axis=-1)

print("Depth map created!")

# Normalize depth map to 0–255
depth_normalized = cv2.normalize(depth_map, None, 0, 255, cv2.NORM_MINMAX)
depth_normalized = depth_normalized.astype('uint8')

# Apply color map (JET = blue → green → red)
depth_colored = cv2.applyColorMap(depth_normalized, cv2.COLORMAP_JET)

# Convert BGR to RGB for display
depth_rgb = cv2.cvtColor(depth_colored, cv2.COLOR_BGR2RGB)

# Show result
plt.imshow(depth_rgb)
plt.title("Enhanced Depth Map")
plt.axis("off")
plt.show()